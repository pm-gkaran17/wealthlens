# WealthLens – Publishing & Monetisation Guide

A complete guide to go from these files to a live, money-making website.

---

## 📁 File Structure

```
wealthlens/
├── index.html        ← Landing page (home)
├── app.html          ← The visualiser tool
├── css/
│   ├── style.css     ← Shared styles (nav, buttons, landing page)
│   └── app.css       ← App page styles
└── js/
    ├── data.js       ← All asset data (edit this to add more stocks)
    └── app.js        ← All app logic (chart, search, calculations)
```

---

## 🚀 Step 1: Publish the Website (Free)

### Option A – Netlify (Easiest, Recommended)
1. Go to https://netlify.com and sign up free
2. Click "Add new site" → "Deploy manually"
3. Drag and drop the entire `wealthlens` folder
4. Your site is live in 30 seconds at a URL like `wealthlens.netlify.app`
5. To use a custom domain (e.g. wealthlens.in): buy it on GoDaddy/Namecheap (~₹800/year) and connect it in Netlify settings

### Option B – GitHub Pages (Also free)
1. Create a free GitHub account at github.com
2. Create a new repository called `wealthlens`
3. Upload all files
4. Go to Settings → Pages → Deploy from main branch
5. Site goes live at `yourusername.github.io/wealthlens`

### Option C – Vercel
1. Go to https://vercel.com, sign up with GitHub
2. Import your GitHub repository
3. Click Deploy — done

---

## 💰 Step 2: Monetise with Google AdSense

### Setup
1. Go to https://adsense.google.com
2. Sign up with a Google account
3. Enter your website URL
4. Google reviews it (takes 1–14 days)
5. Once approved, you get a code snippet like:
   ```html
   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossorigin="anonymous"></script>
   ```

### Where to place ads in your files
In `app.html`, find the comment `<!-- Replace with Google AdSense code -->` and replace the placeholder div with your AdSense unit code.

There are already 3 ad slots built in:
- Top banner (728×90) — high visibility
- Sidebar rectangle (300×250) — best performing format
- Bottom banner (728×90)

### Expected earnings
- 1,000 visitors/month → ₹500–₹2,000/month
- 10,000 visitors/month → ₹5,000–₹20,000/month
- Earnings depend on user location and engagement

---

## 💳 Step 3: Monetise with Paid Subscriptions

The pricing page is already built (Free vs Pro plans). To actually collect payments:

### Easiest: Razorpay (Indian, no setup fee)
1. Sign up at https://razorpay.com
2. Complete KYC (PAN + bank account)
3. Create a "Payment Link" or "Subscription Plan" for ₹199/month
4. Add the payment button to your pricing page

```html
<!-- Replace the "Start 7-day free trial" button with: -->
<script src="https://checkout.razorpay.com/v1/payment-button.js"
  data-payment_button_id="YOUR_BUTTON_ID" async>
</script>
```

### Alternative: Instamojo (Even simpler)
1. Sign up at https://www.instamojo.com
2. Create a product/subscription
3. Share the payment link directly

### What Pro features to actually build
Currently the Pro features (inflation-adjusted, SIP mode) are labelled but not locked.
To actually gate them:
- Add a simple login check: if user is logged in + paid → show Pro features
- Easiest approach: use a service like Memberstack or Outseta that handles this without coding

---

## 📈 Step 4: Get Your First Users

### Free traffic (SEO)
- Add your site to Google Search Console (search.google.com/search-console)
- Write blog posts like "What if I had invested ₹10,000 in Titan in 2010?"
- Share comparisons on Twitter/X, Reddit (r/IndiaInvestments), and financial WhatsApp groups

### Communities to share in
- r/IndiaInvestments on Reddit
- ValueResearchOnline forums
- Twitter/X with hashtags #NiftyIndia #IndianStocks #PersonalFinance

---

## 🔧 Step 5: Connect Real Data (Optional, Later)

The app currently uses estimated CAGR data. To show real historical prices:

1. Sign up at https://twelvedata.com (free tier: 800 API calls/day)
2. Get your API key
3. In `js/app.js`, replace the `getValue()` function with a real API call

```javascript
// Example: fetch real data from Twelve Data
async function getRealHistory(symbol, startYear) {
  const apiKey = 'YOUR_KEY_HERE';
  const url = `https://api.twelvedata.com/time_series?symbol=${symbol}.NSE&interval=1year&outputsize=25&apikey=${apiKey}`;
  const res = await fetch(url);
  const data = await res.json();
  return data.values; // array of {datetime, close}
}
```

---

## 📋 Legal Pages to Add (Important for Monetisation)

Before applying for AdSense and accepting payments, add these pages:

1. **Privacy Policy** – Required by AdSense
   - Use a free generator: https://www.privacypolicygenerator.info

2. **Disclaimer** – Already added in the app (the grey box at the bottom)

3. **Terms of Service** – Required for paid subscriptions
   - Use: https://www.termsfeed.com/terms-service-generator/

Create `privacy.html` and `terms.html` files and link them in the footer.

---

## 💡 Ideas to Grow the Product

- **SIP Calculator** – monthly investment mode (top requested feature)
- **Inflation-adjusted returns** – show real vs nominal returns
- **Share as image** – let users share their portfolio comparison
- **WhatsApp/Telegram bot** – users can type "TITAN 2010" and get the value
- **Email newsletter** – weekly "What if you had invested in X?"
- **Comparisons blog** – "Gold vs Nifty 50: Last 20 years"

---

*Built with HTML, CSS, and JavaScript. No frameworks needed. Easy to edit.*
